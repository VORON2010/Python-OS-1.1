﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Diagnostics; 
namespace OS_1._1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            
        }

        

        string FilePath1 = @"C:\Users\Voron\source\repos\OS 1.1\OS 1.1\bin\systemfiles\game\game.py";
        string FilePath2 = @"C:\Users\Voron\source\repos\OS 1.1\OS 1.1\bin\systemfiles\bash.py";
        string FilePath3 = @"C:\Users\Voron\source\repos\OS 1.1\OS 1.1\bin\systemfiles\calculator.py";
        string FilePath4 = @"C:\Users\Voron\source\repos\OS 1.1\OS 1.1\bin\systemfiles\syspaint.py";
        string FilePath5 = @"C:\Users\Voron\source\repos\OS 1.1\OS 1.1\bin\systemfiles\notpixelpaint.py";
        string FilePath6 = @"C:\Users\Voron\source\repos\OS 1.1\OS 1.1\bin\systemfiles\notepad.py";
        string FilePath7 = @"C:\Users\Voron\source\repos\OS 1.1\OS 1.1\bin\systemfiles\clicker\main.py";

        int key = 1350;

        string key1 = Interaction.InputBox("Введите Ключ" , "Активация Python OS");

        
        
        
        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void myCraft15ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start(FilePath1);
        }

        private void bahToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start(FilePath2);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Process.Start(FilePath1);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Process.Start(FilePath2);
        }

        private void eXITToolStripMenuItem_Click(object sender, EventArgs e)
        {
         DialogResult =  MessageBox.Show("Вы уверены что хотите выйти?", "Подтверждение выхода", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (DialogResult == DialogResult.Yes)
            {
                Application.Exit();
            }
            
            

            
        }

        private void calculatorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start(FilePath3);
        }

        private void paintToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start(FilePath4);
        }

        private void pixelPaintToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start(FilePath5);
        }

        private void notePadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start(FilePath6);
        }

        private void cliCkerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start(FilePath7);
        }
    }
}

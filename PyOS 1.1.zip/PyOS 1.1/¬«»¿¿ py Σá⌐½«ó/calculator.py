import tkinter as tk
from tkinter import messagebox


class Calculator:
    def __init__(self, root):
        self.root = root
        self.root.title("Калькулятор")
        self.root.geometry("400x400")
        self.root.resizable(False, False)

        self.current_expression = ""
        self.create_widgets()

    def create_widgets(self):
        # Экран калькулятора
        self.display = tk.Entry(self.root, font=("Arial", 24), borderwidth=2, relief="solid", justify="right")
        self.display.grid(row=0, column=0, columnspan=4, padx=10, pady=10)

        # Кнопки калькулятора
        buttons = [
            ('7', 1, 0), ('8', 1, 1), ('9', 1, 2), ('/', 1, 3),
            ('4', 2, 0), ('5', 2, 1), ('6', 2, 2), ('*', 2, 3),
            ('1', 3, 0), ('2', 3, 1), ('3', 3, 2), ('-', 3, 3),
            ('0', 4, 0), ('.', 4, 1), ('+', 4, 2), ('=', 4, 3),
            ('C', 5, 0, 2), ('Exit', 5, 2, 2)  # Обновлено: добавлен colspan для 'C' и 'Exit'
        ]

        for (text, row, col, *colspan) in buttons:
            colspan = colspan[0] if colspan else 1  # Устанавливаем colspan по умолчанию
            self.create_button(text, row, col, colspan)

    def create_button(self, text, row, col, colspan=1):
        button = tk.Button(self.root, text=text, font=("Arial", 18), width=5, height=2,
                           command=lambda: self.on_button_click(text))
        button.grid(row=row, column=col, columnspan=colspan, padx=5, pady=5)

    def on_button_click(self, text):
        if text == 'C':
            # Очистка текущего выражения и экрана
            self.current_expression = ""
            self.update_display()
        elif text == 'Exit':
            self.root.quit()
        elif text == '=':
            try:
                # Оценка выражения и отображение результата
                result = str(eval(self.current_expression))
                self.current_expression = result
            except Exception as e:
                # Обработка ошибок
                messagebox.showerror("Ошибка", "Неверное выражение")
                self.current_expression = ""
            self.update_display()
        else:
            # Добавление текста к текущему выражению
            self.current_expression += text
            self.update_display()

    def update_display(self):
        self.display.delete(0, tk.END)
        self.display.insert(tk.END, self.current_expression)


if __name__ == "__main__":
    root = tk.Tk()
    app = Calculator(root)
    root.mainloop()

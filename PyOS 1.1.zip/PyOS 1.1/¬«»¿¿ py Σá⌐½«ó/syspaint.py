import pygame
import sys

# Инициализация Pygame
pygame.init()

# Параметры окна
WINDOW_WIDTH, WINDOW_HEIGHT = 800, 600
GRID_SIZE = 20
GRID_WIDTH = WINDOW_WIDTH // GRID_SIZE
GRID_HEIGHT = WINDOW_HEIGHT // GRID_SIZE

# Цвета для палитр
PALETTES = [
    [  # Палитра 1
        (255, 0, 0),   # Красный
        (0, 255, 0),   # Зеленый
        (0, 0, 255),   # Синий
        (0, 0, 0),     # Черный
        (255, 255, 255) # Белый
    ],
    [  # Палитра 2
        (255, 165, 0), # Оранжевый
        (255, 255, 0), # Желтый
        (0, 255, 255), # Голубой
        (255, 0, 255), # Пурпурный
        (128, 128, 128) # Серый
    ],
    [  # Палитра 3
        (128, 0, 128), # Фиолетовый
        (255, 105, 180), # Розовый
        (0, 128, 128), # Тёмно-бирюзовый
        (0, 128, 0),   # Темно-зеленый
        (255, 192, 203) # Светло-розовый
    ]
]

# Инициализация окна
screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption('Пиксельный редактор')

# Текущая палитра
current_palette_index = 0
current_palette = PALETTES[current_palette_index]
current_color = current_palette[0]

# Создание холста
canvas = [[(255, 255, 255) for _ in range(GRID_WIDTH)] for _ in range(GRID_HEIGHT)]

def draw_grid():
    for x in range(0, WINDOW_WIDTH, GRID_SIZE):
        pygame.draw.line(screen, (0, 0, 0), (x, 0), (x, WINDOW_HEIGHT - GRID_SIZE))
    for y in range(0, WINDOW_HEIGHT - GRID_SIZE, GRID_SIZE):
        pygame.draw.line(screen, (0, 0, 0), (0, y), (WINDOW_WIDTH, y))

def draw_canvas():
    for y in range(GRID_HEIGHT):
        for x in range(GRID_WIDTH):
            pygame.draw.rect(screen, canvas[y][x], (x * GRID_SIZE, y * GRID_SIZE, GRID_SIZE, GRID_SIZE))

def draw_palette():
    palette_surface = pygame.Surface((WINDOW_WIDTH, GRID_SIZE))
    for i, color in enumerate(current_palette):
        pygame.draw.rect(palette_surface, color, (i * GRID_SIZE, 0, GRID_SIZE, GRID_SIZE))
    screen.blit(palette_surface, (0, WINDOW_HEIGHT - GRID_SIZE))

def get_grid_position(mouse_x, mouse_y):
    return mouse_x // GRID_SIZE, mouse_y // GRID_SIZE

def save_canvas():
    pygame.image.save(screen, 'pixel_art.png')

def clear_canvas():
    global canvas
    canvas = [[(255, 255, 255) for _ in range(GRID_WIDTH)] for _ in range(GRID_HEIGHT)]

# Главный цикл программы
drawing = False
running = True
while running:
    screen.fill((255, 255, 255))
    draw_canvas()
    draw_grid()
    draw_palette()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse_x, mouse_y = event.pos
            if mouse_y >= WINDOW_HEIGHT - GRID_SIZE:
                color_index = mouse_x // GRID_SIZE
                if 0 <= color_index < len(current_palette):
                    current_color = current_palette[color_index]
            else:
                drawing = True
                grid_x, grid_y = get_grid_position(mouse_x, mouse_y)
                if 0 <= grid_x < GRID_WIDTH and 0 <= grid_y < GRID_HEIGHT:
                    canvas[grid_y][grid_x] = current_color

        if event.type == pygame.MOUSEBUTTONUP:
            drawing = False

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_s:
                save_canvas()
            if event.key == pygame.K_c:
                clear_canvas()
            if event.key == pygame.K_p:
                current_palette_index = (current_palette_index + 1) % len(PALETTES)
                current_palette = PALETTES[current_palette_index]
                current_color = current_palette[0]

    if drawing:
        mouse_x, mouse_y = pygame.mouse.get_pos()
        grid_x, grid_y = get_grid_position(mouse_x, mouse_y)
        if 0 <= grid_x < GRID_WIDTH and 0 <= grid_y < GRID_HEIGHT:
            canvas[grid_y][grid_x] = current_color

    pygame.display.flip()


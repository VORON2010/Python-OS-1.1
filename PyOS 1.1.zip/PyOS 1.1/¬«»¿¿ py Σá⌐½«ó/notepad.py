import pygame
import sys
import os

# Инициализация Pygame
pygame.init()

# Параметры окна
WINDOW_WIDTH, WINDOW_HEIGHT = 800, 600
FONT_SIZE = 24
FONT_COLOR = (0, 0, 0)
BG_COLOR = (255, 255, 255)
TEXT_COLOR = (0, 0, 0)

# Настройки шрифта
font = pygame.font.Font(None, FONT_SIZE)

# Инициализация окна
screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption('Текстовый редактор')

# Переменные для текста
text = ""
cursor_pos = 0
text_lines = []
line_height = FONT_SIZE + 4

# Функция для обновления текста на экране
def draw_text():
    screen.fill(BG_COLOR)  # Очистка экрана

    # Отображение текста
    y_offset = 0
    for line in text_lines:
        text_surface = font.render(line, True, TEXT_COLOR)
        screen.blit(text_surface, (10, y_offset))
        y_offset += line_height

    # Отображение фиксированной строки внизу окна
    info_text = "Для сохранения нажмите Ctrl+S, для открытия Ctrl+O"
    info_surface = font.render(info_text, True, TEXT_COLOR)
    screen.blit(info_surface, (10, WINDOW_HEIGHT - FONT_SIZE - 10))

    pygame.display.flip()

# Функция для обновления списка строк текста
def update_text_lines():
    global text_lines
    text_lines = []
    lines = text.split('\n')
    for line in lines:
        text_lines.append(line)

# Функция для сохранения файла
def save_file(filepath):
    with open(filepath, 'w') as file:
        file.write(text)

# Функция для открытия файла
def open_file(filepath):
    global text
    with open(filepath, 'r') as file:
        text = file.read()
    update_text_lines()
    draw_text()

# Основной цикл программы
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False

            elif event.key == pygame.K_s and pygame.key.get_mods() & pygame.KMOD_CTRL:
                # Сохранение файла при нажатии Ctrl+S
                save_file('untitled.txt')

            elif event.key == pygame.K_o and pygame.key.get_mods() & pygame.KMOD_CTRL:
                # Открытие файла при нажатии Ctrl+O
                open_file('untitled.txt')

            elif event.key == pygame.K_BACKSPACE:
                # Удаление символа перед курсором
                if cursor_pos > 0:
                    text = text[:cursor_pos - 1] + text[cursor_pos:]
                    cursor_pos -= 1
                    update_text_lines()
                    draw_text()

            elif event.key == pygame.K_DELETE:
                # Удаление символа после курсора
                if cursor_pos < len(text):
                    text = text[:cursor_pos] + text[cursor_pos + 1:]
                    update_text_lines()
                    draw_text()

            elif event.key == pygame.K_RETURN:
                # Вставка новой строки
                text = text[:cursor_pos] + '\n' + text[cursor_pos:]
                cursor_pos += 1
                update_text_lines()
                draw_text()

            elif event.key == pygame.K_LEFT:
                # Перемещение курсора влево
                if cursor_pos > 0:
                    cursor_pos -= 1

            elif event.key == pygame.K_RIGHT:
                # Перемещение курсора вправо
                if cursor_pos < len(text):
                    cursor_pos += 1

            elif event.key >= pygame.K_SPACE and event.key <= pygame.K_z:
                # Вставка символа
                text = text[:cursor_pos] + event.unicode + text[cursor_pos:]
                cursor_pos += 1
                update_text_lines()
                draw_text()

    draw_text()

    pygame.time.delay(30)  # Задержка для управления частотой обновления экрана

pygame.quit()
sys.exit()

import pygame
import sys
import random

# Инициализация Pygame
pygame.init()

# Параметры окна
WINDOW_WIDTH, WINDOW_HEIGHT = 800, 600
PALETTE_HEIGHT = 50

# Цвета для палитр
PALETTES = [
    [  # Палитра 1
        (255, 0, 0),   # Красный
        (0, 255, 0),   # Зеленый
        (0, 0, 255),   # Синий
        (0, 0, 0),     # Черный
        (255, 255, 255) # Белый
    ],
    [  # Палитра 2
        (255, 165, 0), # Оранжевый
        (255, 255, 0), # Желтый
        (0, 255, 255), # Голубой
        (255, 0, 255), # Пурпурный
        (128, 128, 128) # Серый
    ],
    [  # Палитра 3
        (128, 0, 128), # Фиолетовый
        (255, 105, 180), # Розовый
        (0, 128, 128), # Тёмно-бирюзовый
        (0, 128, 0),   # Темно-зеленый
        (255, 192, 203) # Светло-розовый
    ]
]

# Инициализация окна
screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption('Рисовалка')

# Выбор случайной палитры
current_palette_index = random.randint(0, len(PALETTES) - 1)
current_palette = PALETTES[current_palette_index]
current_color = current_palette[0]

# Переменные для рисования
drawing = False
last_pos = None

def draw_palette():
    palette_surface = pygame.Surface((WINDOW_WIDTH, PALETTE_HEIGHT))
    for i, color in enumerate(current_palette):
        pygame.draw.rect(palette_surface, color, (i * (WINDOW_WIDTH // len(current_palette)), 0, WINDOW_WIDTH // len(current_palette), PALETTE_HEIGHT))
    screen.blit(palette_surface, (0, WINDOW_HEIGHT - PALETTE_HEIGHT))

def get_color_from_palette(mouse_x, mouse_y):
    if mouse_y >= WINDOW_HEIGHT - PALETTE_HEIGHT:
        color_index = mouse_x // (WINDOW_WIDTH // len(current_palette))
        if 0 <= color_index < len(current_palette):
            return current_palette[color_index]
    return None

def clear_canvas():
    screen.fill((0, 0, 0))  # Заполнение экрана черным
    draw_palette()

# Изначально заполняем экран черным цветом и отображаем палитру
clear_canvas()

# Главный цикл программы
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse_x, mouse_y = event.pos
            new_color = get_color_from_palette(mouse_x, mouse_y)
            if new_color:
                current_color = new_color
            else:
                drawing = True
                last_pos = mouse_x, mouse_y

        if event.type == pygame.MOUSEBUTTONUP:
            drawing = False
            last_pos = None

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_c:
                clear_canvas()
            if event.key == pygame.K_p:
                # Переключаем палитру
                current_palette_index = (current_palette_index + 1) % len(PALETTES)
                current_palette = PALETTES[current_palette_index]
                current_color = current_palette[0]
                # Очистка экрана и отображение новой палитры
                clear_canvas()

    if drawing:
        mouse_x, mouse_y = pygame.mouse.get_pos()
        if last_pos:
            pygame.draw.line(screen, current_color, last_pos, (mouse_x, mouse_y), 5)
            last_pos = mouse_x, mouse_y

    pygame.display.flip()
